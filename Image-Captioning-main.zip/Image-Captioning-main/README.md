

## 📌 Project Overview

This project demonstrates how to use **Computer Vision + Deep Learning** to extract **high-level visual features** from images with the help of **VGG16**, a powerful convolutional neural network.

The features are categorized symbolically into:

- 🔷 **Edges** – sharp transitions, outlines, contours
- 🔶 **Shapes** – basic geometric forms detected
- 🟫 **Textures** – repeating visual patterns
- 🟪 **Patterns** – complex combinations & abstractions

The interface is built with **Gradio**, providing a clean and user-friendly way to test the system instantly from your browser.

---



## 🔍 Features

- ✅ Load and preprocess any image using `TensorFlow/Keras`
- ✅ Use **VGG16 (pre-trained)** for feature extraction
- ✅ Flatten and split the **4096-d feature vector** into symbolic categories
- ✅ Compute and display average values for each visual group
- ✅ Built-in **Gradio web UI** for easy interaction
- ✅ User-friendly results with explanatory notes

---

## 📁 Folder Structure

```bash
📦 Image-Feature-Extractor-VGG16
├── 📜 Image captioning.ipynb     # Jupyter Notebook with full code
├── 📄 README.md                  # Project documentation (this file)
└── 📦 assets/                    # Optional folder for sample images or screenshots
```

---

## 🚀 Installation & Usage

### 1️⃣ Clone this Repository

```bash
git clone https://github.com/yourusername/Image-Feature-Extractor-VGG16.git
cd Image-Feature-Extractor-VGG16
```

### 2️⃣ Install Dependencies

```bash
pip install tensorflow gradio
```

### 3️⃣ Run the Jupyter Notebook

Open the notebook:

```bash
jupyter notebook Image\ captioning.ipynb
```

or run directly in any Python environment:

```bash
python app.py
```

A **Gradio interface** will launch in your browser 👇

---

## 💡 How It Works

🔬 **Step-by-Step Pipeline**:
1. Upload image via Gradio UI
2. Preprocess image for VGG16 input
3. Extract features from VGG16's `fc2` layer (4096-d vector)
4. Divide the features into 4 visual categories:
   - `Edges = features[0:1000]`
   - `Shapes = features[1000:2000]`
   - `Textures = features[2000:3000]`
   - `Patterns = features[3000:4096]`
5. Calculate and display **mean feature value** for each group
6. Present a readable summary for users

---

## 🧠 Behind the Science

VGG16 is a 16-layer deep convolutional neural network trained on **ImageNet**. The feature vector from the second last layer (`fc2`) is commonly used for **transfer learning** and **image understanding**.

These features are **not directly interpretable** by humans, so we’ve grouped them to give an intuitive understanding of how a neural network perceives visual content.

---

## 🧪 Sample Output

```
🔍 Visual Feature Summary

🟦 Edges: 0.2183
🟩 Shapes: 0.4621
🟫 Textures: 0.1283
🟪 Patterns: 0.3457

📘 These values reflect how strongly the model detected each visual category in your image.
```

---

## 📚 Technologies Used

| Tool        | Purpose                          |
|-------------|----------------------------------|
| `TensorFlow` | Feature extraction with VGG16     |
| `Keras`      | Model loading and preprocessing   |
| `Gradio`     | UI for image upload and display   |
| `NumPy`      | Feature vector handling           |

---

## 📽️ Project Status

✅ Completed core implementation  
🔄 Can be extended to generate full **image captions** using RNN or Transformer in future  
📈 Suitable for demos, AI portfolios, and internships

---

## 👨‍💻 Developed By

> 🎓 **Harsh Vardhan Singh**  
> AI & Data Science Intern @ CodSoft  
> 🔗 [LinkedIn](https://www.linkedin.com/) | 📧 singhharshvardhan178@gmail.com

---

## 📄 License

This project is licensed under the **MIT License**.  
Feel free to use, modify, and share with credit.

