
# 📸 Face Detection & Recognition Web App  
**AI-Powered Face Detection in Images and Videos**  
![Python](https://img.shields.io/badge/python-3.7%2B-blue.svg) ![Flask](https://img.shields.io/badge/flask-2.x-lightgrey) ![OpenCV](https://img.shields.io/badge/opencv-4.x-green) ![face_recognition](https://img.shields.io/badge/face--recognition-1.x-orange)  

---

## 🧠 About the Project

This is a **Flask-based AI Web Application** that allows users to:
- Upload **images or videos**
- **Detect** and **count** the number of faces present
- Works with both **static images** and **video frames**
- Combines the power of **deep learning-based face detection** using the `face_recognition` library and real-time video processing with **OpenCV**

Whether you're experimenting with computer vision, building AI tools, or just curious about face detection — this app is simple, efficient, and extensible.

---

## 🚀 Features

✅ Upload `.jpg`, `.png`, `.mp4`, `.avi` files  
✅ Detect faces in static images  
✅ Frame-by-frame face detection in video  
✅ Return total face count  
✅ Fully functional browser-based interface  
✅ Uploads folder is auto-created if missing  
✅ Lightweight and fast

---

## 🧰 Tech Stack

| Tool               | Purpose                                         |
|--------------------|-------------------------------------------------|
| **Flask**          | Web server & routing                            |
| **OpenCV (cv2)**   | Frame extraction & video analysis               |
| **face_recognition** | Face detection using dlib & deep learning     |
| **HTML/CSS**       | Upload form UI                                  |
| **Python (3.7+)**  | Core logic                                      |
| **os**             | File management                                 |

---

## 📂 Project Structure

```
face-detection-app/
│
├── app.py                  # Main Flask application
├── uploads/                # Uploaded image/video files (auto-created)
├── templates/              # HTML templates (optional if you use Jinja2 separately)
└── README.md               # You are here!
```

---

## 📸 Sample Interface

```html
<h1>Upload an Image or Video for Face Detection</h1>
<form action="/upload" method="post" enctype="multipart/form-data">
    <input type="file" name="file" accept="image/*,video/*" required>
    <input type="submit" value="Upload">
</form>
```



---

## 🧑‍💻 Getting Started

### 🔧 Prerequisites
Make sure you have Python **3.7+** installed.

Install the required libraries:
```bash
pip install flask opencv-python face_recognition
```

> ⚠️ If you're using Windows, and `face_recognition` or `dlib` throws errors during installation, follow this [installation guide](https://www.pyimagesearch.com/2018/06/18/face-recognition-with-opencv-python-and-deep-learning/).

---

### 🔨 How to Run the App

``
## Step 1: Clone this repo
git clone https://github.com/your-username/face-detection-app.git
cd face-detection-app
``
## Step 2: Create uploads folder (optional)
mkdir uploads
``
## Step 3: Run the Flask app
python app.py
``

Open your browser and go to:  
➡️ `http://localhost:5000`

---

## 🖼️ How It Works

1. **User uploads** an image or video.
2. Flask saves the file to the `uploads/` directory.
3. The backend determines whether it’s an **image or video**.
4. Using `face_recognition`, it:
   - For images: detects faces and returns the **face count**.
   - For videos: loops through each frame to detect faces.
5. The count is returned on screen with optional output logging.

---

## ✅ Example Outputs

### For Image:
```
✅ Number of faces detected in the image: 2
```

### For Video:
```
✅ Total number of faces detected in the video: 137
```

---

## 🌟 Future Enhancements

- [ ] Display annotated output image (with bounding boxes)
- [ ] Support drag-and-drop uploads
- [ ] Add live camera stream detection
- [ ] Integrate face **recognition** (match with known people)
- [ ] Save uploaded files with timestamped names

---

## 🤝 Contributing

Contributions are welcome! Here's how you can help:
- Open a pull request 🛠
- Suggest new features ✨
- Report bugs 🐛

---

## 📄 License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for more details.

---

## 💬 Contact
   
📧 singhharshvardhan178@gmail.com    
🔗 [GitHub](https://github.com/harsh0904-dot)

---

