let difficulty = "hard"; // Default difficulty
document.getElementById("difficulty").addEventListener("change", (e) => {
    difficulty = e.target.value;
});

// 🎵 Load Sound Files (Fix)
const clickSound = new Audio("../static/click.mp3");
const winSound = new Audio("../static/win.mp3");
const loseSound = new Audio("../static/lose.mp3");

clickSound.preload = "auto";
winSound.preload = "auto";
loseSound.preload = "auto";

let gameOver = false;

// Function to handle player's move
function playerMove(index) {
    if (gameOver) return;

    let cell = document.querySelectorAll(".cell")[index];
    if (cell.innerText !== "") return; // Prevent clicking on filled cells

    clickSound.play(); // 🔊 Play click sound
    cell.innerText = "X"; // Player move

    fetch("/ai-move", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ move: index, difficulty: difficulty })
    })
    .then(response => response.json())
    .then(data => {
        updateBoard(data.board);
        if (data.winner) endGame(data.winner);
    });
}

// Function to update the board
function updateBoard(board) {
    document.querySelectorAll(".cell").forEach((cell, index) => {
        cell.innerText = board[index];
    });
}

// Function to end the game
function endGame(winner) {
    gameOver = true;
    let statusText = document.getElementById("status");

    if (winner === "X") {
        statusText.innerText = "🎉 You Win!";
        winSound.play(); // 🔊 Play win sound
    } else if (winner === "O") {
        statusText.innerText = "😢 AI Wins!";
        loseSound.play(); // 🔊 Play lose sound
    } else {
        statusText.innerText = "😐 It's a Draw!";
    }
}

// Reset the game (Fix)
function resetGame() {
    gameOver = false;  // ✅ Fix: Ensure the game resets
    fetch("/reset-game", { method: "POST" })  // Call backend reset function
    .then(() => {
        document.querySelectorAll(".cell").forEach(cell => cell.innerText = ""); // Clear board UI
        document.getElementById("status").innerText = ""; // Clear message
    });
}
