from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# Initialize empty board
board = [" " for _ in range(9)]  # 3x3 grid stored as a list

# Check if a player has won
def check_winner(board, player):
    win_conditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  # Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  # Columns
        [0, 4, 8], [2, 4, 6]  # Diagonals
    ]
    return any(all(board[i] == player for i in condition) for condition in win_conditions)

# Minimax Algorithm for Hard Mode
def minimax(board, depth, is_max):
    if check_winner(board, "O"): return 1  # AI Wins
    if check_winner(board, "X"): return -1  # Player Wins
    if " " not in board: return 0  # Draw

    if is_max:
        best_score = -float("inf")
        for i in range(9):
            if board[i] == " ":
                board[i] = "O"
                score = minimax(board, depth + 1, False)
                board[i] = " "
                best_score = max(score, best_score)
        return best_score
    else:
        best_score = float("inf")
        for i in range(9):
            if board[i] == " ":
                board[i] = "X"
                score = minimax(board, depth + 1, True)
                board[i] = " "
                best_score = min(score, best_score)
        return best_score

# AI Move Function with Difficulty Levels
def ai_move(difficulty):
    if difficulty == "easy":
        return random.choice([i for i in range(9) if board[i] == " "])
    elif difficulty == "medium":
        return best_move(random_factor=0.3)  # 30% chance of a random move
    else:
        return best_move(random_factor=0)  # Hard mode (Minimax always optimal)

def best_move(random_factor=0):
    best_score = -float("inf")
    move = None
    for i in range(9):
        if board[i] == " ":
            board[i] = "O"
            score = minimax(board, 0, False)
            board[i] = " "
            if score > best_score or (random.random() < random_factor):
                best_score = score
                move = i
    return move

# API: AI's Move
@app.route("/ai-move", methods=["POST"])
def get_ai_move():
    global board
    data = request.get_json()
    player_move = data["move"]
    difficulty = data["difficulty"]

    if board[player_move] == " ":
        board[player_move] = "X"  # Player move

    if check_winner(board, "X"):
        return jsonify({"board": board, "winner": "X"})

    if " " not in board:
        return jsonify({"board": board, "winner": "draw"})

    ai_choice = ai_move(difficulty)
    if ai_choice is not None:
        board[ai_choice] = "O"

    winner = None
    if check_winner(board, "O"):
        winner = "O"
    elif " " not in board:
        winner = "draw"

    return jsonify({"board": board, "winner": winner})

# Reset Game API (Fix)
@app.route("/reset-game", methods=["POST"])
def reset_game():
    global board
    board = [" " for _ in range(9)]
    return jsonify({"message": "Game reset"})

# Serve the game page
@app.route("/")
def home():
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
