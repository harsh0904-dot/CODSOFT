📜 README.md 
 
 Tic-Tac-Toe AI (Python + Flask)  
An AI-powered Tic-Tac-Toe game using Python (Flask), JavaScript, and the Minimax Algorithm.
Play Against an Unbeatable AI with adjustable difficulty settings!  

## About This Project
This is an interactive **Tic-Tac-Toe game** where players compete against an **AI-powered bot**. The AI opponent is implemented using the **Minimax Algorithm**, making it an **unbeatable AI** in Hard Mode.  

Why This Project?
- Learn AI Logic – Understand how the Minimax algorithm works.  
- Fun & Challenging – Play against an adaptive AI with multiple difficulty levels.  
- Full-Stack Development– Combines Flask, JavaScript, and AJAX for a real-time gaming experience.  

## Features
✅ Play Against AI – Challenge an AI opponent with three difficulty levels (Easy, Medium, Hard).  
✅ Unbeatable AI (Minimax) – Hard mode uses the Minimax algorithm for optimal play.  
✅ Interactive UI – Animated game board with hover effects.  
✅ Sound Effects – Click sounds, win/lose sounds for better experience.  
✅ Game Restart Function – Restart the game anytime without refreshing the page.  
✅ Mobile-Friendly – Fully responsive on desktop & mobile browsers.  

## Game Rules
1️. You play as "X", AI plays as "O". 
2️. Players take turns placing their symbols on a 3x3 grid.  
3️. Win Conditions: 
   - Get three in a row, column, or diagonal to win.  
   - If the grid is full with no winner, it's a draw.  
4️. AI Opponent:  
   - Easy Mode: Random moves, easy to beat.  
   - Medium Mode: 30% chance of random moves, moderate difficulty.  
   - Hard Mode: Uses Minimax Algorithm, nearly impossible to beat.  

## Tech Stack
| Component | Technology Used|
|--------------|--------------------|
| Backend | Flask (Python) |
| Frontend| HTML, CSS, JavaScript |
| Game AI | Minimax Algorithm |
| Web Server | Flask |
| Communication | AJAX (Fetch API) |

## Project Structure
tic_tac_toe_ai/ │── app.py # Flask Backend (AI Logic) │── requirements.txt # Dependencies list │── templates/ │ └── index.html # Frontend (Game UI) │── static/ │ ├── style.css # CSS for Styling │ ├── script.js # JavaScript for Game Logic │ ├── click.mp3 # Click Sound │ ├── win.mp3 # Win Sound │ ├── lose.mp3 # Lose Sound └── README.md # Documentation


## Installation & Setup
### 1️. Clone the Repository
```
git clone https://github.com/YOUR_USERNAME/tic_tac_toe_ai.git
cd tic_tac_toe_ai.
```

### 2️. Create a Virtual Environment (Optional)
```
python -m venv venv
source venv/bin/activate   # On macOS/Linux
venv\Scripts\activate      # On Windows
```
### 3️. Install Dependencies
```
pip install -r requirements.txt
```

### 4️. Run the Flask Server
```
python app.py
✅ The server will start at http://127.0.0.1:5000/.
✅ Open the link in your browser to start playing.
```


## Sound Effects

•	Click Sound – When a player clicks a cell.

•	Win Sound – When the player wins.

•	Lose Sound – When the AI wins.
If Sounds Are Not Playing:

•	Ensure click.mp3, win.mp3, and lose.mp3 are inside the static/ folder.

•	Some browsers block autoplay sounds. Click once before sounds work.


## Deployment (Make Your Game Public)

Deploy on Render (Easiest)

1️. Create a free account at Render.

2️. Click "New Web Service" → Connect your GitHub repository.

3️. Set Start Command to:
python app.py

4️. Click Deploy! 🎉


## Customization Guide:

1️. Change AI Difficulty (Modify app.py)
To make AI easier/harder, change the random_factor in best_move():
def best_move(random_factor=0.3):  # Adjust this value
•	random_factor=0.3 → AI makes mistakes 30% of the time (Medium).
•	random_factor=0 → AI always plays optimally (Hard Mode).
•	random_factor=0.5 → AI makes random moves 50% of the time (Easiest).

2️. Modify UI (Edit style.css)
To change the board colors and animations, modify static/style.css:
.cell {
    background: #ffffff;  /* Change to any color */
    border-radius: 10px;  /* Make cells round */
    transition: transform 0.2s ease-in-out;
}

## Contributing:

1️. Fork this repository.

2️. Clone your forked repo:
git clone https://github.com/harsh0904-dot/tic_tac_toe_ai.git

3️. Create a new branch for modifications:
git checkout -b feature-name

4️. Commit your changes:
git add .
git commit -m "Added new game feature"

5️. Push and open a pull request:
git push origin feature-name



📄 License

This project is open-source and available under the MIT License.

📧 Contact

📩 Have questions? Reach out to me:


•	📧 Email: singhharshvardhan178@gmail.com


