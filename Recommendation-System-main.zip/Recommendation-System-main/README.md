# Movie Recommendation System

## 📌 Project Overview
This project is a **Movie Recommendation System** that suggests movies to users based on their preferences. It utilizes **collaborative filtering** and **content-based filtering** techniques to provide personalized movie recommendations. The system is implemented in Jupyter Notebook using Python.

## 🚀 Features
- **Content-Based Filtering**: Recommends movies based on their genre, keywords, and description.
- **Collaborative Filtering**: Suggests movies based on user preferences and interactions.
- **Interactive GUI**: A user-friendly interface to enter movie preferences and get recommendations.
- **Search by Genre, Movie Name, or Rating**: Users can explore recommendations based on different criteria.

## 🛠️ Technologies Used
- **Python**
- **Jupyter Notebook**
- **Pandas, NumPy** (Data Processing)
- **Scikit-learn** (Machine Learning & Vectorization)
- **Tkinter / Streamlit** (GUI for interactive recommendations)

## 📂 Project Structure
```
├── Movie Recommendation.ipynb  # Jupyter Notebook with the recommendation system
├── dataset/                    # Contains the dataset used for recommendations
├── README.md                    # Project Documentation
└── requirements.txt              # List of required Python libraries
```

## 📥 Installation
1. **Clone the repository:**
   ```bash
   git clone https://github.com/yourusername/CODSOFT.git
   cd CODSOFT/Movie-Recommendation-System
   ```
2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
3. **Run the Jupyter Notebook:**
   ```bash
   jupyter notebook
   ```

## 📊 How to Use
1. **Open** the Jupyter Notebook.
2. **Run all cells** to load the dataset and initialize the recommendation system.
3. **Enter movie name, genre, or rating** to receive relevant recommendations.

## 🔍 Example Output
Here is an example of a movie recommendation result:
```
Enter Movie Name: Inception
Top Recommendations:
1. Interstellar
2. The Prestige
3. The Dark Knight
4. Shutter Island
5. Memento
```

## 📁 Dataset Details
- The dataset used for this recommendation system is based on **movie metadata**.
- It includes columns such as **title, genre, overview, popularity, ratings, and keywords**.
- Preprocessing includes **text vectorization** (TF-IDF) and similarity calculation.
- The dataset is stored in CSV format inside the `dataset/` folder.

## 🌐 Web Deployment Guide
To deploy this project as a **web application**:
1. **Convert the Jupyter Notebook into a Python script**:
   ```bash
   jupyter nbconvert --to script "Movie Recommendation.ipynb"
   ```
2. **Use Streamlit or Flask** for a web-based interface.
3. **Deploy on a cloud platform** like Heroku, Render, or AWS.
4. **Ensure dependencies are listed in `requirements.txt`**.

## 🎯 Future Improvements
- Implement **hybrid recommendation** (combining content-based and collaborative filtering).
- Improve **user interface** for better interaction.
- Deploy as a **web app** using Streamlit or Flask.

## 📜 License
This project is open-source and available under the [MIT License](LICENSE).

## 📞 Contact
For queries or suggestions, reach out via **LinkedIn** or **GitHub Issues**.

---
🔹 *#CodSoft Internship Project*  | 🔹 *Task: Movie Recommendation System*

